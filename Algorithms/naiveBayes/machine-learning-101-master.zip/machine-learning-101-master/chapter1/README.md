## Data set and code for the Chapter 1: Naive Bayes ##

### Blog Link ###

Theory about Naive Bayes
https://medium.com/machine-learning-101/chapter-1-supervised-learning-and-naive-bayes-classification-part-1-theory-8b9e361897d5

Coding example:
https://medium.com/machine-learning-101/chapter-1-supervised-learning-and-naive-bayes-classification-part-2-coding-5966f25f1475
